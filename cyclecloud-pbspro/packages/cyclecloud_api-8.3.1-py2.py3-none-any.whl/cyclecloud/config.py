import os
import hmac
import hashlib
import binascii
from array import array

import six
from six.moves import range
from six.moves.configparser import RawConfigParser as _RawConfigParser
from requests.structures import CaseInsensitiveDict as _CaseInsensitiveDict

DEFAULT_CONFIG_FILE = os.path.expanduser(os.path.join("~", ".cycle", "config.ini"))


def get_config(config_file=None):
    '''Reads a specified config (or the default) into a nested dictionary.'''

    if config_file:
        if not os.path.isfile(config_file):
            raise ValueError("Specified config file does not exist.")
    else:
        config_file = DEFAULT_CONFIG_FILE

    if os.path.isfile(config_file):
        config_sections = _parse_sections(config_file)
        return _process_config(config_sections)

    return {}


def _parse_sections(config_file):
    '''Dump an ini config file into a nested dictionary data structure.'''

    p = _RawConfigParser()
    p.read(config_file)

    config_sections = _CaseInsensitiveDict()

    for section_name in p.sections():
        if section_name not in config_sections:
            config_sections[section_name] = _CaseInsensitiveDict()

        section = config_sections[section_name]
        for option_name in p.options(section_name):
            section[option_name] = p.get(section_name, option_name)

    return config_sections


def _process_config(config_sections):
    '''Apply some conversions to the config like parsing integers and booleans.'''

    # cyclecloud section settings overwrite those of cycleserver
    if "cycleserver" in config_sections:
        cs_section = config_sections["cycleserver"]
        del config_sections["cycleserver"]
        cs_section.update(config_sections.get("cyclecloud", {}))
        config_sections["cyclecloud"] = cs_section
    elif not "cyclecloud" in config_sections:
        config_sections["cyclecloud"] = _CaseInsensitiveDict()

    cc_section = config_sections["cyclecloud"]

    if not cc_section.get("password") and cc_section.get("key"):
        key = cc_section["key"]
        cc_section["password"] = _p3_decode(key)
        del cc_section["key"]

    if cc_section.get("timeout"):
        cc_section["timeout"] = int(cc_section["timeout"])

    if cc_section.get("verify_certificates"):
        cc_section["verify_certificates"] = cc_section["verify_certificates"].lower() in ["true"]
    elif cc_section.get("verify"):
        cc_section["verify_certificates"] = cc_section["verify"].lower() in ["true"]

    if "verify" in cc_section:
        del cc_section["verify"]

    return config_sections


# ************** beginning of legacy p3 decrypt support **************

for typecode in 'IL':
    if len(array(typecode, [0]).tobytes()) == 4:
        _uint32 = typecode
        break
    else:
        raise RuntimeError("Neither 'I' nor 'L' are unsigned 32-bit integers.")


def _p3_decode(text):
    cipher = six.ensure_binary(text, encoding="utf-8")
    cipher = binascii.unhexlify(cipher)
    return _p3_decrypt(cipher, b"09087a22d7e26f97")


def _expand_key(key, clen):
    blocks = (clen + 19) // 20
    xkey = []
    seed = key
    for _ in range(blocks):
        seed = hashlib.sha1(key + seed).digest()
        xkey.append(seed)
    j = b"".join(xkey)
    return array(_uint32, j)


def _p3_decrypt(cipher, key):
    _ivlen = 16
    _maclen = 8

    n = len(cipher) - _ivlen - _maclen # length of ciphertext
    if n < 0:
        raise ValueError("invalid ciphertext")

    nonce = cipher[:_ivlen]
    stream = cipher[_ivlen:-_maclen] + b'0000'[n & 3:]
    auth = cipher[-_maclen:]

    H = lambda s: hashlib.sha1(s).digest()
    k_enc = H(b'enc' + key + nonce)
    k_auth = H(b'auth' + key + nonce)

    _hmac = lambda msg, key: hmac.new(key, msg, hashlib.sha1).digest()
    vauth = _hmac(cipher[:-_maclen], k_auth)[:_maclen]
    if auth != vauth:
        raise ValueError("invalid key or ciphertext")

    stream = array(_uint32, stream)
    xkey = _expand_key(k_enc, n + 4)
    for i in range(len(stream)):
        stream[i] = stream[i] ^ xkey[i]
    plain = stream.tobytes()[:n]
    return plain

# ************** end of legacy p3 decrypt support **************
