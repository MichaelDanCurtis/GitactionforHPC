# -*- coding: utf-8 -*-
#
# Generated Code - Do Not Edit
#


import json
import platform
import six

__IS_JYTHON__ = platform.system().lower() == "java"


if __IS_JYTHON__:
    from com.microsoft.cyclecloud.model import ClusterUsageInterval as _ClusterUsageInterval


    def json_decode(json_string):
        return _ClusterUsageInterval.json_decode(json_string)


    def from_dict(dict_obj):
        return _ClusterUsageInterval.from_dict(dict_obj)


    def ClusterUsageInterval(**kwargs):
        obj = _ClusterUsageInterval()
        for k, v in six.iteritems(kwargs):
            setattr(obj, k, v)
        return obj


    ClusterUsageInterval.json_decode = _ClusterUsageInterval.json_decode
    ClusterUsageInterval.from_dict = _ClusterUsageInterval.from_dict


else:
    from .ClusterUsageItemModule import ClusterUsageItem


    def json_decode(json_string):
        return ClusterUsageInterval.json_decode(json_string)


    def from_dict(dict_obj):
        return ClusterUsageInterval.from_dict(dict_obj)


    class ClusterUsageInterval(object):
        """
        The usage over one of the intervals in the output
        breakdown: [ClusterUsageItem], The breakdown of usage in this interval, by category of "node" and "nodearray"
, Required
        end: string, The end of the interval (exclusive), Required
        start: string, The beginning of the interval (inclusive), Required
        total: ClusterUsageItem, , Required
        """

        def __init__(self, **kwargs):
            self.breakdown = kwargs.get('breakdown')
            self.end = kwargs.get('end')
            self.start = kwargs.get('start')
            self.total = kwargs.get('total')

        def validate(self):
            """
            Verify that all required properties are set.
            """
            if self.breakdown is None:
                raise ValueError('Property ClusterUsageInterval.breakdown is required.')
            if self.end is None:
                raise ValueError('Property ClusterUsageInterval.end is required.')
            if self.start is None:
                raise ValueError('Property ClusterUsageInterval.start is required.')
            if self.total is None:
                raise ValueError('Property ClusterUsageInterval.total is required.')

        def to_dict(self):
            """
            Creates a dict representation of the object.
            """
            dict_obj = {}
            if self.breakdown is not None:
                dict_obj["breakdown"] = [v.to_dict() for v in self.breakdown]

            if self.end is not None:
                dict_obj["end"] = self.end

            if self.start is not None:
                dict_obj["start"] = self.start

            if self.total is not None:
                dict_obj["total"] = self.total.to_dict()

            return dict_obj

        def json_encode(self):
            return json.dumps(self, default=lambda x: x if type(x) is dict else x.to_dict())

        @staticmethod
        def from_dict(dict_obj):
            """
            Static initializer to create an instance from a dictionary.
            """
            if dict_obj is None:
                return None

            # Convert dictionary keys to lowercase
            dict_obj = dict((k.lower(), v) for k, v in six.iteritems(dict_obj))

            obj = ClusterUsageInterval()

            value = dict_obj.get('breakdown')
            if value is not None:
                obj.breakdown = []
                for item in value:
                    obj.breakdown.append(ClusterUsageItem.from_dict(item))

            value = dict_obj.get('end')
            if value is not None:
                obj.end = value

            value = dict_obj.get('start')
            if value is not None:
                obj.start = value

            value = dict_obj.get('total')
            if value is not None:
                obj.total = ClusterUsageItem.from_dict(value)

            return obj

        @staticmethod
        def json_decode(json_string):
            """
            Static initializer to create an instance from a json string.
            """
            dict_obj = json.loads(json_string)
            return ClusterUsageInterval.from_dict(dict_obj)

        def __eq__(self, other):
            if not hasattr(other, "to_dict"):
                return False
            return self.to_dict() == other.to_dict()

        @property
        def breakdown(self):
            """
            breakdown: [ClusterUsageItem], The breakdown of usage in this interval, by category of "node" and "nodearray"
, Required
            """
            return self._breakdown

        @breakdown.setter
        def breakdown(self, value):
            """
            breakdown: [ClusterUsageItem], The breakdown of usage in this interval, by category of "node" and "nodearray"
, Required
            """
            if value:
                if type(value) is not list:
                    raise TypeError('Must supply a list for ClusterUsageInterval.breakdown.')
            self._breakdown = value

        @property
        def end(self):
            """
            end: string, The end of the interval (exclusive), Required
            """
            return self._end

        @end.setter
        def end(self, value):
            """
            end: string, The end of the interval (exclusive), Required
            """
            self._end = value

        @property
        def start(self):
            """
            start: string, The beginning of the interval (inclusive), Required
            """
            return self._start

        @start.setter
        def start(self, value):
            """
            start: string, The beginning of the interval (inclusive), Required
            """
            self._start = value

        @property
        def total(self):
            """
            total: ClusterUsageItem, , Required
            """
            return self._total

        @total.setter
        def total(self, value):
            """
            total: ClusterUsageItem, , Required
            """
            if value:
                if isinstance(value, dict):
                    value = ClusterUsageItem.from_dict(value)
                if not isinstance(value, ClusterUsageItem):
                    raise TypeError('Value for ClusterUsageInterval.total must be ClusterUsageItem or dict')
            self._total = value

