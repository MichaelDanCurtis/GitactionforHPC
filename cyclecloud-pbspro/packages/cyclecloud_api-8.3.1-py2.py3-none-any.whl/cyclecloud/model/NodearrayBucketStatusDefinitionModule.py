# -*- coding: utf-8 -*-
#
# Generated Code - Do Not Edit
#


import json
import platform
import six

__IS_JYTHON__ = platform.system().lower() == "java"


if __IS_JYTHON__:
    from com.microsoft.cyclecloud.model import NodearrayBucketStatusDefinition as _NodearrayBucketStatusDefinition


    def json_decode(json_string):
        return _NodearrayBucketStatusDefinition.json_decode(json_string)


    def from_dict(dict_obj):
        return _NodearrayBucketStatusDefinition.from_dict(dict_obj)


    def NodearrayBucketStatusDefinition(**kwargs):
        obj = _NodearrayBucketStatusDefinition()
        for k, v in six.iteritems(kwargs):
            setattr(obj, k, v)
        return obj


    NodearrayBucketStatusDefinition.json_decode = _NodearrayBucketStatusDefinition.json_decode
    NodearrayBucketStatusDefinition.from_dict = _NodearrayBucketStatusDefinition.from_dict


else:


    def json_decode(json_string):
        return NodearrayBucketStatusDefinition.json_decode(json_string)


    def from_dict(dict_obj):
        return NodearrayBucketStatusDefinition.from_dict(dict_obj)


    class NodearrayBucketStatusDefinition(object):
        """
        The properties of this bucket, used to create nodes from this bucket. The create-nodes API takes this definition in its `bucket` property.

        machine_type: string, The VM size of the virtual machine, Required
        """

        def __init__(self, **kwargs):
            self.machine_type = kwargs.get('machine_type')

        def validate(self):
            """
            Verify that all required properties are set.
            """
            if self.machine_type is None:
                raise ValueError('Property NodearrayBucketStatusDefinition.machine_type is required.')

        def to_dict(self):
            """
            Creates a dict representation of the object.
            """
            dict_obj = {}
            if self.machine_type is not None:
                dict_obj["machineType"] = self.machine_type

            return dict_obj

        def json_encode(self):
            return json.dumps(self, default=lambda x: x if type(x) is dict else x.to_dict())

        @staticmethod
        def from_dict(dict_obj):
            """
            Static initializer to create an instance from a dictionary.
            """
            if dict_obj is None:
                return None

            # Convert dictionary keys to lowercase
            dict_obj = dict((k.lower(), v) for k, v in six.iteritems(dict_obj))

            obj = NodearrayBucketStatusDefinition()

            value = dict_obj.get('machinetype')
            if value is not None:
                obj.machine_type = value

            return obj

        @staticmethod
        def json_decode(json_string):
            """
            Static initializer to create an instance from a json string.
            """
            dict_obj = json.loads(json_string)
            return NodearrayBucketStatusDefinition.from_dict(dict_obj)

        def __eq__(self, other):
            if not hasattr(other, "to_dict"):
                return False
            return self.to_dict() == other.to_dict()

        @property
        def machine_type(self):
            """
            machine_type: string, The VM size of the virtual machine, Required
            """
            return self._machine_type

        @machine_type.setter
        def machine_type(self, value):
            """
            machine_type: string, The VM size of the virtual machine, Required
            """
            self._machine_type = value

