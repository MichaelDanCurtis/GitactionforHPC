# -*- coding: utf-8 -*-
#
# Generated Code - Do Not Edit
#


import json
import platform
import six

__IS_JYTHON__ = platform.system().lower() == "java"


if __IS_JYTHON__:
    from com.microsoft.cyclecloud.model import NodeCreationRequest as _NodeCreationRequest


    def json_decode(json_string):
        return _NodeCreationRequest.json_decode(json_string)


    def from_dict(dict_obj):
        return _NodeCreationRequest.from_dict(dict_obj)


    def NodeCreationRequest(**kwargs):
        obj = _NodeCreationRequest()
        for k, v in six.iteritems(kwargs):
            setattr(obj, k, v)
        return obj


    NodeCreationRequest.json_decode = _NodeCreationRequest.json_decode
    NodeCreationRequest.from_dict = _NodeCreationRequest.from_dict


else:
    from .NodeCreationRequestSetModule import NodeCreationRequestSet


    def json_decode(json_string):
        return NodeCreationRequest.json_decode(json_string)


    def from_dict(dict_obj):
        return NodeCreationRequest.from_dict(dict_obj)


    class NodeCreationRequest(object):
        """
        Specifies how to add nodes to a cluster
        request_id: string, Optional user-supplied unique token to prevent duplicate operations in case of network communication errors.  If this is included and matches an earlier request id, the server ignores this request and returns a 409 error.
, Optional
        sets: [NodeCreationRequestSet], A list of node definitions to create. The request must contain at least one set. Each set can specify a different set of properties.
, Required
        """

        def __init__(self, **kwargs):
            self.request_id = kwargs.get('request_id')
            self.sets = kwargs.get('sets')

        def validate(self):
            """
            Verify that all required properties are set.
            """
            if self.sets is None:
                raise ValueError('Property NodeCreationRequest.sets is required.')

        def to_dict(self):
            """
            Creates a dict representation of the object.
            """
            dict_obj = {}
            if self.request_id is not None:
                dict_obj["requestId"] = self.request_id

            if self.sets is not None:
                dict_obj["sets"] = [v.to_dict() for v in self.sets]

            return dict_obj

        def json_encode(self):
            return json.dumps(self, default=lambda x: x if type(x) is dict else x.to_dict())

        @staticmethod
        def from_dict(dict_obj):
            """
            Static initializer to create an instance from a dictionary.
            """
            if dict_obj is None:
                return None

            # Convert dictionary keys to lowercase
            dict_obj = dict((k.lower(), v) for k, v in six.iteritems(dict_obj))

            obj = NodeCreationRequest()

            value = dict_obj.get('requestid')
            if value is not None:
                obj.request_id = value

            value = dict_obj.get('sets')
            if value is not None:
                obj.sets = []
                for item in value:
                    obj.sets.append(NodeCreationRequestSet.from_dict(item))

            return obj

        @staticmethod
        def json_decode(json_string):
            """
            Static initializer to create an instance from a json string.
            """
            dict_obj = json.loads(json_string)
            return NodeCreationRequest.from_dict(dict_obj)

        def __eq__(self, other):
            if not hasattr(other, "to_dict"):
                return False
            return self.to_dict() == other.to_dict()

        @property
        def request_id(self):
            """
            request_id: string, Optional user-supplied unique token to prevent duplicate operations in case of network communication errors.  If this is included and matches an earlier request id, the server ignores this request and returns a 409 error.
, Optional
            """
            return self._request_id

        @request_id.setter
        def request_id(self, value):
            """
            request_id: string, Optional user-supplied unique token to prevent duplicate operations in case of network communication errors.  If this is included and matches an earlier request id, the server ignores this request and returns a 409 error.
, Optional
            """
            self._request_id = value

        @property
        def sets(self):
            """
            sets: [NodeCreationRequestSet], A list of node definitions to create. The request must contain at least one set. Each set can specify a different set of properties.
, Required
            """
            return self._sets

        @sets.setter
        def sets(self, value):
            """
            sets: [NodeCreationRequestSet], A list of node definitions to create. The request must contain at least one set. Each set can specify a different set of properties.
, Required
            """
            if value:
                if type(value) is not list:
                    raise TypeError('Must supply a list for NodeCreationRequest.sets.')
            self._sets = value

