# -*- coding: utf-8 -*-
#
# Generated Code - Do Not Edit
#


import json
import platform
import six

__IS_JYTHON__ = platform.system().lower() == "java"


if __IS_JYTHON__:
    from com.microsoft.cyclecloud.model import ClusterUsageItem as _ClusterUsageItem


    def json_decode(json_string):
        return _ClusterUsageItem.json_decode(json_string)


    def from_dict(dict_obj):
        return _ClusterUsageItem.from_dict(dict_obj)


    def ClusterUsageItem(**kwargs):
        obj = _ClusterUsageItem()
        for k, v in six.iteritems(kwargs):
            setattr(obj, k, v)
        return obj


    ClusterUsageItem.json_decode = _ClusterUsageItem.json_decode
    ClusterUsageItem.from_dict = _ClusterUsageItem.from_dict


else:
    from .ClusterUsageDetailsModule import ClusterUsageDetails


    def json_decode(json_string):
        return ClusterUsageItem.json_decode(json_string)


    def from_dict(dict_obj):
        return ClusterUsageItem.from_dict(dict_obj)


    class ClusterUsageItem(object):
        """
        
        category: ['cluster', 'node', 'nodearray'], "cluster" for the overall usage; "node" for a single non-array head node; "nodearray" for a whole nodearray
, Required
        cost: float, The amount that would be charged for this usage, in US dollars and at retail rates. Note: all cost amounts are estimates and are not reflective of the actual bill!
, Optional
        details: [ClusterUsageDetails], Details of VM size used by a nodearray including hours, core_count, region priority and operating system.
, Optional
        hours: float, The number of core-hours of usage for this category, Required
        node: string, The name of the node or nodearray the usage is for (absent for cluster-level data), Optional
        """
        valid_category = ["cluster", "node", "nodearray"]

        def __init__(self, **kwargs):
            self.category = kwargs.get('category')
            self.cost = kwargs.get('cost')
            self.details = kwargs.get('details')
            self.hours = kwargs.get('hours')
            self.node = kwargs.get('node')

        def validate(self):
            """
            Verify that all required properties are set.
            """
            if self.category is None:
                raise ValueError('Property ClusterUsageItem.category is required.')
            if self.hours is None:
                raise ValueError('Property ClusterUsageItem.hours is required.')

        def to_dict(self):
            """
            Creates a dict representation of the object.
            """
            dict_obj = {}
            if self.category is not None:
                dict_obj["category"] = self.category

            if self.cost is not None:
                dict_obj["cost"] = self.cost

            if self.details is not None:
                dict_obj["details"] = [v.to_dict() for v in self.details]

            if self.hours is not None:
                dict_obj["hours"] = self.hours

            if self.node is not None:
                dict_obj["node"] = self.node

            return dict_obj

        def json_encode(self):
            return json.dumps(self, default=lambda x: x if type(x) is dict else x.to_dict())

        @staticmethod
        def from_dict(dict_obj):
            """
            Static initializer to create an instance from a dictionary.
            """
            if dict_obj is None:
                return None

            # Convert dictionary keys to lowercase
            dict_obj = dict((k.lower(), v) for k, v in six.iteritems(dict_obj))

            obj = ClusterUsageItem()

            value = dict_obj.get('category')
            if value is not None:
                obj.category = value

            value = dict_obj.get('cost')
            if value is not None:
                obj.cost = value

            value = dict_obj.get('details')
            if value is not None:
                obj.details = []
                for item in value:
                    obj.details.append(ClusterUsageDetails.from_dict(item))

            value = dict_obj.get('hours')
            if value is not None:
                obj.hours = value

            value = dict_obj.get('node')
            if value is not None:
                obj.node = value

            return obj

        @staticmethod
        def json_decode(json_string):
            """
            Static initializer to create an instance from a json string.
            """
            dict_obj = json.loads(json_string)
            return ClusterUsageItem.from_dict(dict_obj)

        def __eq__(self, other):
            if not hasattr(other, "to_dict"):
                return False
            return self.to_dict() == other.to_dict()

        @property
        def category(self):
            """
            category: ['cluster', 'node', 'nodearray'], "cluster" for the overall usage; "node" for a single non-array head node; "nodearray" for a whole nodearray
, Required
            """
            return self._category

        @category.setter
        def category(self, value):
            """
            category: ['cluster', 'node', 'nodearray'], "cluster" for the overall usage; "node" for a single non-array head node; "nodearray" for a whole nodearray
, Required
            """
            self._category = value

        @property
        def cost(self):
            """
            cost: float, The amount that would be charged for this usage, in US dollars and at retail rates. Note: all cost amounts are estimates and are not reflective of the actual bill!
, Optional
            """
            return self._cost

        @cost.setter
        def cost(self, value):
            """
            cost: float, The amount that would be charged for this usage, in US dollars and at retail rates. Note: all cost amounts are estimates and are not reflective of the actual bill!
, Optional
            """
            self._cost = value

        @property
        def details(self):
            """
            details: [ClusterUsageDetails], Details of VM size used by a nodearray including hours, core_count, region priority and operating system.
, Optional
            """
            return self._details

        @details.setter
        def details(self, value):
            """
            details: [ClusterUsageDetails], Details of VM size used by a nodearray including hours, core_count, region priority and operating system.
, Optional
            """
            if value:
                if type(value) is not list:
                    raise TypeError('Must supply a list for ClusterUsageItem.details.')
            self._details = value

        @property
        def hours(self):
            """
            hours: float, The number of core-hours of usage for this category, Required
            """
            return self._hours

        @hours.setter
        def hours(self, value):
            """
            hours: float, The number of core-hours of usage for this category, Required
            """
            self._hours = value

        @property
        def node(self):
            """
            node: string, The name of the node or nodearray the usage is for (absent for cluster-level data), Optional
            """
            return self._node

        @node.setter
        def node(self, value):
            """
            node: string, The name of the node or nodearray the usage is for (absent for cluster-level data), Optional
            """
            self._node = value

