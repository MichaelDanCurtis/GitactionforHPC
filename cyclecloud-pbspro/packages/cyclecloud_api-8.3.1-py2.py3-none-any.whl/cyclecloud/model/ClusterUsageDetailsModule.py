# -*- coding: utf-8 -*-
#
# Generated Code - Do Not Edit
#


import json
import platform
import six

__IS_JYTHON__ = platform.system().lower() == "java"


if __IS_JYTHON__:
    from com.microsoft.cyclecloud.model import ClusterUsageDetails as _ClusterUsageDetails


    def json_decode(json_string):
        return _ClusterUsageDetails.json_decode(json_string)


    def from_dict(dict_obj):
        return _ClusterUsageDetails.from_dict(dict_obj)


    def ClusterUsageDetails(**kwargs):
        obj = _ClusterUsageDetails()
        for k, v in six.iteritems(kwargs):
            setattr(obj, k, v)
        return obj


    ClusterUsageDetails.json_decode = _ClusterUsageDetails.json_decode
    ClusterUsageDetails.from_dict = _ClusterUsageDetails.from_dict


else:


    def json_decode(json_string):
        return ClusterUsageDetails.json_decode(json_string)


    def from_dict(dict_obj):
        return ClusterUsageDetails.from_dict(dict_obj)


    class ClusterUsageDetails(object):
        """
        Details of VM sizes used by a nodearray such as VM Sku name, hours, cost, core_count, region, priority and operating system.
        core_count: float, The number of cores in this VM size, Optional
        cost: float, Cost of this VM size, Optional
        hours: float, The number of core-hours of usage for this VM size, Optional
        os: ['Windows', 'Linux'], Type of operating system, Optional
        priority: ['Regular', 'Spot'], Priority of the VM Sku, Optional
        region: string, The region the VM size is instantiated in, Optional
        vm_size: string, VM Sku size, Optional
        """
        valid_os = ["Windows", "Linux"]
        valid_priority = ["Regular", "Spot"]

        def __init__(self, **kwargs):
            self.core_count = kwargs.get('core_count')
            self.cost = kwargs.get('cost')
            self.hours = kwargs.get('hours')
            self.os = kwargs.get('os')
            self.priority = kwargs.get('priority')
            self.region = kwargs.get('region')
            self.vm_size = kwargs.get('vm_size')

        def validate(self):
            """
            Verify that all required properties are set.
            """
            pass

        def to_dict(self):
            """
            Creates a dict representation of the object.
            """
            dict_obj = {}
            if self.core_count is not None:
                dict_obj["core_count"] = self.core_count

            if self.cost is not None:
                dict_obj["cost"] = self.cost

            if self.hours is not None:
                dict_obj["hours"] = self.hours

            if self.os is not None:
                dict_obj["os"] = self.os

            if self.priority is not None:
                dict_obj["priority"] = self.priority

            if self.region is not None:
                dict_obj["region"] = self.region

            if self.vm_size is not None:
                dict_obj["vm_size"] = self.vm_size

            return dict_obj

        def json_encode(self):
            return json.dumps(self, default=lambda x: x if type(x) is dict else x.to_dict())

        @staticmethod
        def from_dict(dict_obj):
            """
            Static initializer to create an instance from a dictionary.
            """
            if dict_obj is None:
                return None

            # Convert dictionary keys to lowercase
            dict_obj = dict((k.lower(), v) for k, v in six.iteritems(dict_obj))

            obj = ClusterUsageDetails()

            value = dict_obj.get('core_count')
            if value is not None:
                obj.core_count = value

            value = dict_obj.get('cost')
            if value is not None:
                obj.cost = value

            value = dict_obj.get('hours')
            if value is not None:
                obj.hours = value

            value = dict_obj.get('os')
            if value is not None:
                obj.os = value

            value = dict_obj.get('priority')
            if value is not None:
                obj.priority = value

            value = dict_obj.get('region')
            if value is not None:
                obj.region = value

            value = dict_obj.get('vm_size')
            if value is not None:
                obj.vm_size = value

            return obj

        @staticmethod
        def json_decode(json_string):
            """
            Static initializer to create an instance from a json string.
            """
            dict_obj = json.loads(json_string)
            return ClusterUsageDetails.from_dict(dict_obj)

        def __eq__(self, other):
            if not hasattr(other, "to_dict"):
                return False
            return self.to_dict() == other.to_dict()

        @property
        def core_count(self):
            """
            core_count: float, The number of cores in this VM size, Optional
            """
            return self._core_count

        @core_count.setter
        def core_count(self, value):
            """
            core_count: float, The number of cores in this VM size, Optional
            """
            self._core_count = value

        @property
        def cost(self):
            """
            cost: float, Cost of this VM size, Optional
            """
            return self._cost

        @cost.setter
        def cost(self, value):
            """
            cost: float, Cost of this VM size, Optional
            """
            self._cost = value

        @property
        def hours(self):
            """
            hours: float, The number of core-hours of usage for this VM size, Optional
            """
            return self._hours

        @hours.setter
        def hours(self, value):
            """
            hours: float, The number of core-hours of usage for this VM size, Optional
            """
            self._hours = value

        @property
        def os(self):
            """
            os: ['Windows', 'Linux'], Type of operating system, Optional
            """
            return self._os

        @os.setter
        def os(self, value):
            """
            os: ['Windows', 'Linux'], Type of operating system, Optional
            """
            self._os = value

        @property
        def priority(self):
            """
            priority: ['Regular', 'Spot'], Priority of the VM Sku, Optional
            """
            return self._priority

        @priority.setter
        def priority(self, value):
            """
            priority: ['Regular', 'Spot'], Priority of the VM Sku, Optional
            """
            self._priority = value

        @property
        def region(self):
            """
            region: string, The region the VM size is instantiated in, Optional
            """
            return self._region

        @region.setter
        def region(self, value):
            """
            region: string, The region the VM size is instantiated in, Optional
            """
            self._region = value

        @property
        def vm_size(self):
            """
            vm_size: string, VM Sku size, Optional
            """
            return self._vm_size

        @vm_size.setter
        def vm_size(self, value):
            """
            vm_size: string, VM Sku size, Optional
            """
            self._vm_size = value

