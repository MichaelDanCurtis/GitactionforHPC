# -*- coding: utf-8 -*-
#
# Generated Code - Do Not Edit
#


import json
import platform
import six

__IS_JYTHON__ = platform.system().lower() == "java"


if __IS_JYTHON__:
    from com.microsoft.cyclecloud.model import ClusterUsage as _ClusterUsage


    def json_decode(json_string):
        return _ClusterUsage.json_decode(json_string)


    def from_dict(dict_obj):
        return _ClusterUsage.from_dict(dict_obj)


    def ClusterUsage(**kwargs):
        obj = _ClusterUsage()
        for k, v in six.iteritems(kwargs):
            setattr(obj, k, v)
        return obj


    ClusterUsage.json_decode = _ClusterUsage.json_decode
    ClusterUsage.from_dict = _ClusterUsage.from_dict


else:
    from .ClusterUsageIntervalModule import ClusterUsageInterval


    def json_decode(json_string):
        return ClusterUsage.json_decode(json_string)


    def from_dict(dict_obj):
        return ClusterUsage.from_dict(dict_obj)


    class ClusterUsage(object):
        """
        Usage and optional cost information for the cluster
        usage: [ClusterUsageInterval], A list of usages by time interval, Required
        """

        def __init__(self, **kwargs):
            self.usage = kwargs.get('usage')

        def validate(self):
            """
            Verify that all required properties are set.
            """
            if self.usage is None:
                raise ValueError('Property ClusterUsage.usage is required.')

        def to_dict(self):
            """
            Creates a dict representation of the object.
            """
            dict_obj = {}
            if self.usage is not None:
                dict_obj["usage"] = [v.to_dict() for v in self.usage]

            return dict_obj

        def json_encode(self):
            return json.dumps(self, default=lambda x: x if type(x) is dict else x.to_dict())

        @staticmethod
        def from_dict(dict_obj):
            """
            Static initializer to create an instance from a dictionary.
            """
            if dict_obj is None:
                return None

            # Convert dictionary keys to lowercase
            dict_obj = dict((k.lower(), v) for k, v in six.iteritems(dict_obj))

            obj = ClusterUsage()

            value = dict_obj.get('usage')
            if value is not None:
                obj.usage = []
                for item in value:
                    obj.usage.append(ClusterUsageInterval.from_dict(item))

            return obj

        @staticmethod
        def json_decode(json_string):
            """
            Static initializer to create an instance from a json string.
            """
            dict_obj = json.loads(json_string)
            return ClusterUsage.from_dict(dict_obj)

        def __eq__(self, other):
            if not hasattr(other, "to_dict"):
                return False
            return self.to_dict() == other.to_dict()

        @property
        def usage(self):
            """
            usage: [ClusterUsageInterval], A list of usages by time interval, Required
            """
            return self._usage

        @usage.setter
        def usage(self, value):
            """
            usage: [ClusterUsageInterval], A list of usages by time interval, Required
            """
            if value:
                if type(value) is not list:
                    raise TypeError('Must supply a list for ClusterUsage.usage.')
            self._usage = value

