# -*- coding: utf-8 -*-
#
# Generated Code - Do Not Edit
#


import json
import platform
import six

__IS_JYTHON__ = platform.system().lower() == "java"


if __IS_JYTHON__:
    from com.microsoft.cyclecloud.model import NodearrayBucketStatus as _NodearrayBucketStatus


    def json_decode(json_string):
        return _NodearrayBucketStatus.json_decode(json_string)


    def from_dict(dict_obj):
        return _NodearrayBucketStatus.from_dict(dict_obj)


    def NodearrayBucketStatus(**kwargs):
        obj = _NodearrayBucketStatus()
        for k, v in six.iteritems(kwargs):
            setattr(obj, k, v)
        return obj


    NodearrayBucketStatus.json_decode = _NodearrayBucketStatus.json_decode
    NodearrayBucketStatus.from_dict = _NodearrayBucketStatus.from_dict


else:
    from .PlacementGroupStatusModule import PlacementGroupStatus
    from .NodearrayBucketStatusVirtualMachineModule import NodearrayBucketStatusVirtualMachine
    from .NodearrayBucketStatusDefinitionModule import NodearrayBucketStatusDefinition


    def json_decode(json_string):
        return NodearrayBucketStatus.json_decode(json_string)


    def from_dict(dict_obj):
        return NodearrayBucketStatus.from_dict(dict_obj)


    class NodearrayBucketStatus(object):
        """
        
        active_core_count: integer, The number of cores in use for this bucket, in this nodearray, Required
        active_count: integer, The number of nodes in use for this bucket, in this nodearray. This includes nodes which are still acquiring a VM.
, Required
        active_nodes: [string], The node names in use for this bucket, in this nodearray. This includes nodes which are still acquiring a VM. This is only included if nodes=true is in the query.
, Optional
        available_core_count: integer, How many extra cores may be created in this bucket, in this nodearray. Always a multiple of availableCount.
, Required
        available_count: integer, How many extra nodes may be created in this bucket, in this nodearray. Note this may be less than implied by maxCount and usedCount, since maxCount may be limited globally.
, Required
        bucket_id: string, The identifier for this bucket. This will always have the same value  for a given bucket in a nodearray, as long as the cluster is not deleted. 
, Required
        consumed_core_count: integer, The number of cores for this family that are already in use across the entire region.
, Required
        definition: NodearrayBucketStatusDefinition, The properties of this bucket, used to create nodes from this bucket. The create-nodes API takes this definition in its `bucket` property.
, Optional
        family_consumed_core_count: integer, The number of cores for this family that are already in use across the entire region.
, Optional
        family_quota_core_count: integer, The number of total cores that can be started for this family in this region. This might not be an integer multiple of quotaCount.
, Optional
        family_quota_count: integer, The number of total instances that can be started (given familyQuotaCoreCount), Optional
        invalid_reason: string, If valid is false, this will contain the reason the bucket is invalid. Currently NotActivated and DisabledMachineType are the only reasons., Required
        max_core_count: integer, The maximum number of cores that may be in this bucket, including global and nodearray limits.  Always a multiple of maxCount.
, Required
        max_count: integer, The maximum number of nodes that may be in this bucket, including global and nodearray limits, Required
        max_placement_group_core_size: integer, The maximum total number of cores that can be in a placement group in this bucket. Always a multiple of maxPlacementGroupSize.
, Required
        max_placement_group_size: integer, The maximum total number of instances that can be in a placement group in this bucket, Required
        placement_groups: [PlacementGroupStatus], The placement groups in use for this nodearray, if any.
, Required
        quota_core_count: integer, The number of total cores that can be started for this family in this region, taking into account the regional quota core count as well. This might not be an integer multiple of quotaCount.
, Required
        quota_count: integer, The number of total instances that can be started (given quotaCoreCount), Required
        regional_consumed_core_count: integer, The number of cores that are already in use across the entire region.
, Optional
        regional_quota_core_count: integer, The number of total cores that can be started in this region. This might not be an integer multiple of regionalQuotaCount.
, Optional
        regional_quota_count: integer, The number of total instances that can be started (given regionalQuotaCoreCount), Optional
        valid: boolean, If true, this bucket represents a currently valid bucket to use for new nodes. If false, this bucket represents existing nodes only., Required
        virtual_machine: NodearrayBucketStatusVirtualMachine, The properties of the virtual machines launched from this bucket, Required
        """

        def __init__(self, **kwargs):
            self.active_core_count = kwargs.get('active_core_count')
            self.active_count = kwargs.get('active_count')
            self.active_nodes = kwargs.get('active_nodes')
            self.available_core_count = kwargs.get('available_core_count')
            self.available_count = kwargs.get('available_count')
            self.bucket_id = kwargs.get('bucket_id')
            self.consumed_core_count = kwargs.get('consumed_core_count')
            self.definition = kwargs.get('definition')
            self.family_consumed_core_count = kwargs.get('family_consumed_core_count')
            self.family_quota_core_count = kwargs.get('family_quota_core_count')
            self.family_quota_count = kwargs.get('family_quota_count')
            self.invalid_reason = kwargs.get('invalid_reason')
            self.max_core_count = kwargs.get('max_core_count')
            self.max_count = kwargs.get('max_count')
            self.max_placement_group_core_size = kwargs.get('max_placement_group_core_size')
            self.max_placement_group_size = kwargs.get('max_placement_group_size')
            self.placement_groups = kwargs.get('placement_groups')
            self.quota_core_count = kwargs.get('quota_core_count')
            self.quota_count = kwargs.get('quota_count')
            self.regional_consumed_core_count = kwargs.get('regional_consumed_core_count')
            self.regional_quota_core_count = kwargs.get('regional_quota_core_count')
            self.regional_quota_count = kwargs.get('regional_quota_count')
            self.valid = kwargs.get('valid')
            self.virtual_machine = kwargs.get('virtual_machine')

        def validate(self):
            """
            Verify that all required properties are set.
            """
            if self.active_core_count is None:
                raise ValueError('Property NodearrayBucketStatus.active_core_count is required.')
            if self.active_count is None:
                raise ValueError('Property NodearrayBucketStatus.active_count is required.')
            if self.available_core_count is None:
                raise ValueError('Property NodearrayBucketStatus.available_core_count is required.')
            if self.available_count is None:
                raise ValueError('Property NodearrayBucketStatus.available_count is required.')
            if self.bucket_id is None:
                raise ValueError('Property NodearrayBucketStatus.bucket_id is required.')
            if self.consumed_core_count is None:
                raise ValueError('Property NodearrayBucketStatus.consumed_core_count is required.')
            if self.invalid_reason is None:
                raise ValueError('Property NodearrayBucketStatus.invalid_reason is required.')
            if self.max_core_count is None:
                raise ValueError('Property NodearrayBucketStatus.max_core_count is required.')
            if self.max_count is None:
                raise ValueError('Property NodearrayBucketStatus.max_count is required.')
            if self.max_placement_group_core_size is None:
                raise ValueError('Property NodearrayBucketStatus.max_placement_group_core_size is required.')
            if self.max_placement_group_size is None:
                raise ValueError('Property NodearrayBucketStatus.max_placement_group_size is required.')
            if self.placement_groups is None:
                raise ValueError('Property NodearrayBucketStatus.placement_groups is required.')
            if self.quota_core_count is None:
                raise ValueError('Property NodearrayBucketStatus.quota_core_count is required.')
            if self.quota_count is None:
                raise ValueError('Property NodearrayBucketStatus.quota_count is required.')
            if self.valid is None:
                raise ValueError('Property NodearrayBucketStatus.valid is required.')
            if self.virtual_machine is None:
                raise ValueError('Property NodearrayBucketStatus.virtual_machine is required.')

        def to_dict(self):
            """
            Creates a dict representation of the object.
            """
            dict_obj = {}
            if self.active_core_count is not None:
                dict_obj["activeCoreCount"] = self.active_core_count

            if self.active_count is not None:
                dict_obj["activeCount"] = self.active_count

            if self.active_nodes is not None:
                dict_obj["activeNodes"] = [v for v in self.active_nodes]

            if self.available_core_count is not None:
                dict_obj["availableCoreCount"] = self.available_core_count

            if self.available_count is not None:
                dict_obj["availableCount"] = self.available_count

            if self.bucket_id is not None:
                dict_obj["bucketId"] = self.bucket_id

            if self.consumed_core_count is not None:
                dict_obj["consumedCoreCount"] = self.consumed_core_count

            if self.definition is not None:
                dict_obj["definition"] = self.definition.to_dict()

            if self.family_consumed_core_count is not None:
                dict_obj["familyConsumedCoreCount"] = self.family_consumed_core_count

            if self.family_quota_core_count is not None:
                dict_obj["familyQuotaCoreCount"] = self.family_quota_core_count

            if self.family_quota_count is not None:
                dict_obj["familyQuotaCount"] = self.family_quota_count

            if self.invalid_reason is not None:
                dict_obj["invalidReason"] = self.invalid_reason

            if self.max_core_count is not None:
                dict_obj["maxCoreCount"] = self.max_core_count

            if self.max_count is not None:
                dict_obj["maxCount"] = self.max_count

            if self.max_placement_group_core_size is not None:
                dict_obj["maxPlacementGroupCoreSize"] = self.max_placement_group_core_size

            if self.max_placement_group_size is not None:
                dict_obj["maxPlacementGroupSize"] = self.max_placement_group_size

            if self.placement_groups is not None:
                dict_obj["placementGroups"] = [v.to_dict() for v in self.placement_groups]

            if self.quota_core_count is not None:
                dict_obj["quotaCoreCount"] = self.quota_core_count

            if self.quota_count is not None:
                dict_obj["quotaCount"] = self.quota_count

            if self.regional_consumed_core_count is not None:
                dict_obj["regionalConsumedCoreCount"] = self.regional_consumed_core_count

            if self.regional_quota_core_count is not None:
                dict_obj["regionalQuotaCoreCount"] = self.regional_quota_core_count

            if self.regional_quota_count is not None:
                dict_obj["regionalQuotaCount"] = self.regional_quota_count

            if self.valid is not None:
                dict_obj["valid"] = self.valid

            if self.virtual_machine is not None:
                dict_obj["virtualMachine"] = self.virtual_machine.to_dict()

            return dict_obj

        def json_encode(self):
            return json.dumps(self, default=lambda x: x if type(x) is dict else x.to_dict())

        @staticmethod
        def from_dict(dict_obj):
            """
            Static initializer to create an instance from a dictionary.
            """
            if dict_obj is None:
                return None

            # Convert dictionary keys to lowercase
            dict_obj = dict((k.lower(), v) for k, v in six.iteritems(dict_obj))

            obj = NodearrayBucketStatus()

            value = dict_obj.get('activecorecount')
            if value is not None:
                obj.active_core_count = value

            value = dict_obj.get('activecount')
            if value is not None:
                obj.active_count = value

            value = dict_obj.get('activenodes')
            if value is not None:
                obj.active_nodes = []
                for item in value:
                    obj.active_nodes.append(item)

            value = dict_obj.get('availablecorecount')
            if value is not None:
                obj.available_core_count = value

            value = dict_obj.get('availablecount')
            if value is not None:
                obj.available_count = value

            value = dict_obj.get('bucketid')
            if value is not None:
                obj.bucket_id = value

            value = dict_obj.get('consumedcorecount')
            if value is not None:
                obj.consumed_core_count = value

            value = dict_obj.get('definition')
            if value is not None:
                obj.definition = NodearrayBucketStatusDefinition.from_dict(value)

            value = dict_obj.get('familyconsumedcorecount')
            if value is not None:
                obj.family_consumed_core_count = value

            value = dict_obj.get('familyquotacorecount')
            if value is not None:
                obj.family_quota_core_count = value

            value = dict_obj.get('familyquotacount')
            if value is not None:
                obj.family_quota_count = value

            value = dict_obj.get('invalidreason')
            if value is not None:
                obj.invalid_reason = value

            value = dict_obj.get('maxcorecount')
            if value is not None:
                obj.max_core_count = value

            value = dict_obj.get('maxcount')
            if value is not None:
                obj.max_count = value

            value = dict_obj.get('maxplacementgroupcoresize')
            if value is not None:
                obj.max_placement_group_core_size = value

            value = dict_obj.get('maxplacementgroupsize')
            if value is not None:
                obj.max_placement_group_size = value

            value = dict_obj.get('placementgroups')
            if value is not None:
                obj.placement_groups = []
                for item in value:
                    obj.placement_groups.append(PlacementGroupStatus.from_dict(item))

            value = dict_obj.get('quotacorecount')
            if value is not None:
                obj.quota_core_count = value

            value = dict_obj.get('quotacount')
            if value is not None:
                obj.quota_count = value

            value = dict_obj.get('regionalconsumedcorecount')
            if value is not None:
                obj.regional_consumed_core_count = value

            value = dict_obj.get('regionalquotacorecount')
            if value is not None:
                obj.regional_quota_core_count = value

            value = dict_obj.get('regionalquotacount')
            if value is not None:
                obj.regional_quota_count = value

            value = dict_obj.get('valid')
            if value is not None:
                obj.valid = value

            value = dict_obj.get('virtualmachine')
            if value is not None:
                obj.virtual_machine = NodearrayBucketStatusVirtualMachine.from_dict(value)

            return obj

        @staticmethod
        def json_decode(json_string):
            """
            Static initializer to create an instance from a json string.
            """
            dict_obj = json.loads(json_string)
            return NodearrayBucketStatus.from_dict(dict_obj)

        def __eq__(self, other):
            if not hasattr(other, "to_dict"):
                return False
            return self.to_dict() == other.to_dict()

        @property
        def active_core_count(self):
            """
            active_core_count: integer, The number of cores in use for this bucket, in this nodearray, Required
            """
            return self._active_core_count

        @active_core_count.setter
        def active_core_count(self, value):
            """
            active_core_count: integer, The number of cores in use for this bucket, in this nodearray, Required
            """
            self._active_core_count = value

        @property
        def active_count(self):
            """
            active_count: integer, The number of nodes in use for this bucket, in this nodearray. This includes nodes which are still acquiring a VM.
, Required
            """
            return self._active_count

        @active_count.setter
        def active_count(self, value):
            """
            active_count: integer, The number of nodes in use for this bucket, in this nodearray. This includes nodes which are still acquiring a VM.
, Required
            """
            self._active_count = value

        @property
        def active_nodes(self):
            """
            active_nodes: [string], The node names in use for this bucket, in this nodearray. This includes nodes which are still acquiring a VM. This is only included if nodes=true is in the query.
, Optional
            """
            return self._active_nodes

        @active_nodes.setter
        def active_nodes(self, value):
            """
            active_nodes: [string], The node names in use for this bucket, in this nodearray. This includes nodes which are still acquiring a VM. This is only included if nodes=true is in the query.
, Optional
            """
            if value:
                if type(value) is not list:
                    raise TypeError('Must supply a list for NodearrayBucketStatus.active_nodes.')
            self._active_nodes = value

        @property
        def available_core_count(self):
            """
            available_core_count: integer, How many extra cores may be created in this bucket, in this nodearray. Always a multiple of availableCount.
, Required
            """
            return self._available_core_count

        @available_core_count.setter
        def available_core_count(self, value):
            """
            available_core_count: integer, How many extra cores may be created in this bucket, in this nodearray. Always a multiple of availableCount.
, Required
            """
            self._available_core_count = value

        @property
        def available_count(self):
            """
            available_count: integer, How many extra nodes may be created in this bucket, in this nodearray. Note this may be less than implied by maxCount and usedCount, since maxCount may be limited globally.
, Required
            """
            return self._available_count

        @available_count.setter
        def available_count(self, value):
            """
            available_count: integer, How many extra nodes may be created in this bucket, in this nodearray. Note this may be less than implied by maxCount and usedCount, since maxCount may be limited globally.
, Required
            """
            self._available_count = value

        @property
        def bucket_id(self):
            """
            bucket_id: string, The identifier for this bucket. This will always have the same value  for a given bucket in a nodearray, as long as the cluster is not deleted. 
, Required
            """
            return self._bucket_id

        @bucket_id.setter
        def bucket_id(self, value):
            """
            bucket_id: string, The identifier for this bucket. This will always have the same value  for a given bucket in a nodearray, as long as the cluster is not deleted. 
, Required
            """
            self._bucket_id = value

        @property
        def consumed_core_count(self):
            """
            consumed_core_count: integer, The number of cores for this family that are already in use across the entire region.
, Required
            """
            return self._consumed_core_count

        @consumed_core_count.setter
        def consumed_core_count(self, value):
            """
            consumed_core_count: integer, The number of cores for this family that are already in use across the entire region.
, Required
            """
            self._consumed_core_count = value

        @property
        def definition(self):
            """
            definition: NodearrayBucketStatusDefinition, The properties of this bucket, used to create nodes from this bucket. The create-nodes API takes this definition in its `bucket` property.
, Optional
            """
            return self._definition

        @definition.setter
        def definition(self, value):
            """
            definition: NodearrayBucketStatusDefinition, The properties of this bucket, used to create nodes from this bucket. The create-nodes API takes this definition in its `bucket` property.
, Optional
            """
            if value:
                if isinstance(value, dict):
                    value = NodearrayBucketStatusDefinition.from_dict(value)
                if not isinstance(value, NodearrayBucketStatusDefinition):
                    raise TypeError('Value for NodearrayBucketStatus.definition must be NodearrayBucketStatusDefinition or dict')
            self._definition = value

        @property
        def family_consumed_core_count(self):
            """
            family_consumed_core_count: integer, The number of cores for this family that are already in use across the entire region.
, Optional
            """
            return self._family_consumed_core_count

        @family_consumed_core_count.setter
        def family_consumed_core_count(self, value):
            """
            family_consumed_core_count: integer, The number of cores for this family that are already in use across the entire region.
, Optional
            """
            self._family_consumed_core_count = value

        @property
        def family_quota_core_count(self):
            """
            family_quota_core_count: integer, The number of total cores that can be started for this family in this region. This might not be an integer multiple of quotaCount.
, Optional
            """
            return self._family_quota_core_count

        @family_quota_core_count.setter
        def family_quota_core_count(self, value):
            """
            family_quota_core_count: integer, The number of total cores that can be started for this family in this region. This might not be an integer multiple of quotaCount.
, Optional
            """
            self._family_quota_core_count = value

        @property
        def family_quota_count(self):
            """
            family_quota_count: integer, The number of total instances that can be started (given familyQuotaCoreCount), Optional
            """
            return self._family_quota_count

        @family_quota_count.setter
        def family_quota_count(self, value):
            """
            family_quota_count: integer, The number of total instances that can be started (given familyQuotaCoreCount), Optional
            """
            self._family_quota_count = value

        @property
        def invalid_reason(self):
            """
            invalid_reason: string, If valid is false, this will contain the reason the bucket is invalid. Currently NotActivated and DisabledMachineType are the only reasons., Required
            """
            return self._invalid_reason

        @invalid_reason.setter
        def invalid_reason(self, value):
            """
            invalid_reason: string, If valid is false, this will contain the reason the bucket is invalid. Currently NotActivated and DisabledMachineType are the only reasons., Required
            """
            self._invalid_reason = value

        @property
        def max_core_count(self):
            """
            max_core_count: integer, The maximum number of cores that may be in this bucket, including global and nodearray limits.  Always a multiple of maxCount.
, Required
            """
            return self._max_core_count

        @max_core_count.setter
        def max_core_count(self, value):
            """
            max_core_count: integer, The maximum number of cores that may be in this bucket, including global and nodearray limits.  Always a multiple of maxCount.
, Required
            """
            self._max_core_count = value

        @property
        def max_count(self):
            """
            max_count: integer, The maximum number of nodes that may be in this bucket, including global and nodearray limits, Required
            """
            return self._max_count

        @max_count.setter
        def max_count(self, value):
            """
            max_count: integer, The maximum number of nodes that may be in this bucket, including global and nodearray limits, Required
            """
            self._max_count = value

        @property
        def max_placement_group_core_size(self):
            """
            max_placement_group_core_size: integer, The maximum total number of cores that can be in a placement group in this bucket. Always a multiple of maxPlacementGroupSize.
, Required
            """
            return self._max_placement_group_core_size

        @max_placement_group_core_size.setter
        def max_placement_group_core_size(self, value):
            """
            max_placement_group_core_size: integer, The maximum total number of cores that can be in a placement group in this bucket. Always a multiple of maxPlacementGroupSize.
, Required
            """
            self._max_placement_group_core_size = value

        @property
        def max_placement_group_size(self):
            """
            max_placement_group_size: integer, The maximum total number of instances that can be in a placement group in this bucket, Required
            """
            return self._max_placement_group_size

        @max_placement_group_size.setter
        def max_placement_group_size(self, value):
            """
            max_placement_group_size: integer, The maximum total number of instances that can be in a placement group in this bucket, Required
            """
            self._max_placement_group_size = value

        @property
        def placement_groups(self):
            """
            placement_groups: [PlacementGroupStatus], The placement groups in use for this nodearray, if any.
, Required
            """
            return self._placement_groups

        @placement_groups.setter
        def placement_groups(self, value):
            """
            placement_groups: [PlacementGroupStatus], The placement groups in use for this nodearray, if any.
, Required
            """
            if value:
                if type(value) is not list:
                    raise TypeError('Must supply a list for NodearrayBucketStatus.placement_groups.')
            self._placement_groups = value

        @property
        def quota_core_count(self):
            """
            quota_core_count: integer, The number of total cores that can be started for this family in this region, taking into account the regional quota core count as well. This might not be an integer multiple of quotaCount.
, Required
            """
            return self._quota_core_count

        @quota_core_count.setter
        def quota_core_count(self, value):
            """
            quota_core_count: integer, The number of total cores that can be started for this family in this region, taking into account the regional quota core count as well. This might not be an integer multiple of quotaCount.
, Required
            """
            self._quota_core_count = value

        @property
        def quota_count(self):
            """
            quota_count: integer, The number of total instances that can be started (given quotaCoreCount), Required
            """
            return self._quota_count

        @quota_count.setter
        def quota_count(self, value):
            """
            quota_count: integer, The number of total instances that can be started (given quotaCoreCount), Required
            """
            self._quota_count = value

        @property
        def regional_consumed_core_count(self):
            """
            regional_consumed_core_count: integer, The number of cores that are already in use across the entire region.
, Optional
            """
            return self._regional_consumed_core_count

        @regional_consumed_core_count.setter
        def regional_consumed_core_count(self, value):
            """
            regional_consumed_core_count: integer, The number of cores that are already in use across the entire region.
, Optional
            """
            self._regional_consumed_core_count = value

        @property
        def regional_quota_core_count(self):
            """
            regional_quota_core_count: integer, The number of total cores that can be started in this region. This might not be an integer multiple of regionalQuotaCount.
, Optional
            """
            return self._regional_quota_core_count

        @regional_quota_core_count.setter
        def regional_quota_core_count(self, value):
            """
            regional_quota_core_count: integer, The number of total cores that can be started in this region. This might not be an integer multiple of regionalQuotaCount.
, Optional
            """
            self._regional_quota_core_count = value

        @property
        def regional_quota_count(self):
            """
            regional_quota_count: integer, The number of total instances that can be started (given regionalQuotaCoreCount), Optional
            """
            return self._regional_quota_count

        @regional_quota_count.setter
        def regional_quota_count(self, value):
            """
            regional_quota_count: integer, The number of total instances that can be started (given regionalQuotaCoreCount), Optional
            """
            self._regional_quota_count = value

        @property
        def valid(self):
            """
            valid: boolean, If true, this bucket represents a currently valid bucket to use for new nodes. If false, this bucket represents existing nodes only., Required
            """
            return self._valid

        @valid.setter
        def valid(self, value):
            """
            valid: boolean, If true, this bucket represents a currently valid bucket to use for new nodes. If false, this bucket represents existing nodes only., Required
            """
            self._valid = value

        @property
        def virtual_machine(self):
            """
            virtual_machine: NodearrayBucketStatusVirtualMachine, The properties of the virtual machines launched from this bucket, Required
            """
            return self._virtual_machine

        @virtual_machine.setter
        def virtual_machine(self, value):
            """
            virtual_machine: NodearrayBucketStatusVirtualMachine, The properties of the virtual machines launched from this bucket, Required
            """
            if value:
                if isinstance(value, dict):
                    value = NodearrayBucketStatusVirtualMachine.from_dict(value)
                if not isinstance(value, NodearrayBucketStatusVirtualMachine):
                    raise TypeError('Value for NodearrayBucketStatus.virtual_machine must be NodearrayBucketStatusVirtualMachine or dict')
            self._virtual_machine = value

