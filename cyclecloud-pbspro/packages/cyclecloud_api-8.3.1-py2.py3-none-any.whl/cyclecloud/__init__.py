from cyclecloud.client import Client

del client
del session
